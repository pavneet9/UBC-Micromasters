package filters;

import twitter4j.Status;

import java.util.List;

/**
 * A filter that represents the logical or of its child filters
 */
public class AndFilter implements Filter {
    private final Filter child1;
    private final Filter child2;

    public AndFilter(Filter child1, Filter child2) {
        this.child1 = child1;
        this.child2 = child2;
    }

    /**
     * A or filter matches when both of the child tweets match the status
     * @param s     the tweets to check
     * @return      whether or not it matches
     */
    @Override
    public boolean matches(Status s) {
        if( child1.matches(s) && child2.matches(s)){
            return true;
        }
        else {
            return false;
        }
    }

    @Override
    public List<String> terms() {
        return child1.terms();
    }

    public String toString() {
        return "("+ child1.toString() + " and " + child2.toString() + ")";
    }
}
