package ui;

import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;

/**
 * A panel to display the current tweet
 */
public class TooltipPanel extends JPanel {
    private BufferedImage userImage;
    private final JTextArea textField = new JTextArea();
    private String text;
    private JLabel pictureLabel;
    
    public TooltipPanel(BufferedImage image, String text) {
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        userImage = image;
        pictureLabel = new JLabel(new ImageIcon(userImage));

        JPanel jPanel = new JPanel();
        jPanel.setLayout(new BoxLayout(jPanel, BoxLayout.X_AXIS));
        JPanel imagePanel = new JPanel();
        imagePanel.setLayout(new BoxLayout(imagePanel, BoxLayout.LINE_AXIS));
        imagePanel.add(pictureLabel);
        jPanel.add(imagePanel);
        jPanel.add(Box.createRigidArea(new Dimension(10, 0)));

        JPanel textPanelContainer = new JPanel();
        textPanelContainer.setLayout(new BoxLayout(textPanelContainer, BoxLayout.LINE_AXIS));
        this.text = text;
        textField.setText(text);
        textField.setEditable(false);
        textField.setLineWrap(true);
        textField.setWrapStyleWord(true);
        textPanelContainer.add(textField);
        textPanelContainer.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        this.add(jPanel);
        this.add(textPanelContainer);

    }

    public void updateContent(BufferedImage image, String text) {
        this.text = text;
        textField.setText(text);
    }

}