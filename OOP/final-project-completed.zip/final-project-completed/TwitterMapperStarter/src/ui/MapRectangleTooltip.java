package ui;

import org.openstreetmap.gui.jmapviewer.Coordinate;
import org.openstreetmap.gui.jmapviewer.Layer;
import org.openstreetmap.gui.jmapviewer.MapRectangleImpl;

import java.awt.*;

public class MapRectangleTooltip extends MapRectangleImpl {
    public static final Color defaultColor = Color.red;

     public MapRectangleTooltip(Layer layer, String name, Coordinate topLeft, Coordinate bottomRight) {
        super(layer, name, topLeft, bottomRight, getDefaultStyle());
         setColor(Color.BLACK);
         setBackColor(defaultColor);

     }
}
