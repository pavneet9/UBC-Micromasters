package ui;

import org.openstreetmap.gui.jmapviewer.Coordinate;
import org.openstreetmap.gui.jmapviewer.Layer;
import org.openstreetmap.gui.jmapviewer.MapMarkerCircle;
import org.openstreetmap.gui.jmapviewer.interfaces.MapMarker;

import java.awt.*;
import java.awt.image.BufferedImage;

public class MapMarkerElaborate extends MapMarkerCircle implements MapMarker {
    public static double defaultMarkerSize = 2.0;
    public static Color defaultColor = Color.red;
    public String text;
    public BufferedImage image;



    public MapMarkerElaborate(Layer layer, Coordinate coord, Color color, String filter, String tweet, String url ) {
        super(layer, null, coord, defaultMarkerSize, STYLE.FIXED, getDefaultStyle());
        setColor(color);
        setBackColor(color);
        this.image = util.Util.imageFromURL(url);
        this.text = tweet;
    }

    //Getters
    public BufferedImage getImage(){
        return image;
    }

    public String getText(){
        return text;
    }
}
